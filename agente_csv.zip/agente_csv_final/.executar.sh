#!/bin/bash

# Script de instalação e execução do Agente CSV Melhorado
# Este script instala as dependências necessárias e executa o aplicativo

echo "=== Agente de Análise de Notas Fiscais - Versão Melhorada ==="
echo "Instalando dependências..."

# Verifica se o Python está instalado
if ! command -v python3 &> /dev/null; then
    echo "Python3 não encontrado. Por favor, instale o Python 3.7 ou superior."
    exit 1
fi

# Instala as dependências
pip3 install gradio pandas plotly

echo "Iniciando o aplicativo..."
echo "O aplicativo será aberto no seu navegador em http://localhost:7860"
echo "Para parar o aplicativo, pressione Ctrl+C"

# Executa o aplicativo
python3 agente_csv_app.py


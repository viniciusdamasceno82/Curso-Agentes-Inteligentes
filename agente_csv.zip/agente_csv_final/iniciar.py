import tkinter as tk
from tkinter import messagebox
import subprocess
import webbrowser
import threading
import time
import os
import sys

class AgenteCSVLauncher:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Agente CSV - Análise de Faturas")
        self.root.geometry("400x600")
        self.root.configure(bg="#2c3e50")
        self.root.resizable(False, False)
        
        # Centraliza a janela na tela
        self.center_window()
        
        # Variável para controlar o processo do servidor
        self.server_process = None
        
        # Cria a interface
        self.create_interface()
        
    def center_window(self):
        self.root.update_idletasks()
        width = self.root.winfo_width()
        height = self.root.winfo_height()
        x = (self.root.winfo_screenwidth() // 2) - (width // 2)
        y = (self.root.winfo_screenheight() // 2) - (height // 2)
        self.root.geometry(f"{width}x{height}+{x}+{y}")
        
    def create_interface(self):
        # Header
        header_frame = tk.Frame(self.root, bg="#3498db", height=80)
        header_frame.pack(fill="x", padx=20, pady=(20, 10))
        header_frame.pack_propagate(False)
        
        # Logo/Icon
        icon_label = tk.Label(header_frame, text="📊", font=("Arial", 32), bg="#3498db", fg="white")
        icon_label.pack(pady=10)
        
        # Title
        title_label = tk.Label(self.root, text="Agente CSV", font=("Arial", 24, "bold"), bg="#2c3e50", fg="white")
        title_label.pack(pady=(10, 5))
        
        subtitle_label = tk.Label(self.root, text="Análise de Faturas", font=("Arial", 14), bg="#2c3e50", fg="#bdc3c7")
        subtitle_label.pack(pady=(0, 20))
        
        # Status
        self.status_frame = tk.Frame(self.root, bg="#34495e", height=60)
        self.status_frame.pack(fill="x", padx=20, pady=10)
        self.status_frame.pack_propagate(False)
        
        self.status_label = tk.Label(self.status_frame, text="🔴 Servidor Parado", font=("Arial", 12), bg="#34495e", fg="white")
        self.status_label.pack(pady=15)
        
        # Buttons
        button_frame = tk.Frame(self.root, bg="#2c3e50")
        button_frame.pack(pady=20)
        
        self.start_button = tk.Button(
            button_frame,
            text="🚀 Iniciar Aplicativo",
            font=("Arial", 14, "bold"),
            bg="#27ae60",
            fg="white",
            width=20,
            height=2,
            command=self.start_server,
            relief="flat",
            cursor="hand2"
        )
        self.start_button.pack(pady=10)
        
        self.open_button = tk.Button(
            button_frame,
            text="🌐 Abrir no Navegador",
            font=("Arial", 12),
            bg="#3498db",
            fg="white",
            width=20,
            height=2,
            command=self.open_browser,
            relief="flat",
            cursor="hand2",
            state="disabled"
        )
        self.open_button.pack(pady=5)
        
        self.stop_button = tk.Button(
            button_frame,
            text="⏹️ Parar Servidor",
            font=("Arial", 12),
            bg="#e74c3c",
            fg="white",
            width=20,
            height=2,
            command=self.stop_server,
            relief="flat",
            cursor="hand2",
            state="disabled"
        )
        self.stop_button.pack(pady=5)
        
        # Info
        info_frame = tk.Frame(self.root, bg="#34495e")
        info_frame.pack(fill="x", padx=20, pady=20)
        
        info_text = """
ℹ️ Informações:
• O aplicativo será executado em localhost:7860
• Aguarde alguns segundos após iniciar
• Use o botão "Fechar" para encerrar tudo
        """
        
        info_label = tk.Label(info_frame, text=info_text, font=("Arial", 10), bg="#34495e", fg="#bdc3c7", justify="left")
        info_label.pack(pady=15, padx=15)
        
        # Close button
        close_button = tk.Button(
            self.root,
            text="❌ Fechar",
            font=("Arial", 12, "bold"),
            bg="#95a5a6",
            fg="white",
            width=15,
            height=2,
            command=self.close_app,
            relief="flat",
            cursor="hand2"
        )
        close_button.pack(pady=(10, 20))
        
        # Protocol para fechar janela
        self.root.protocol("WM_DELETE_WINDOW", self.close_app)
        
    def start_server(self):
        try:
            # Desabilita o botão de iniciar
            self.start_button.config(state="disabled")
            self.status_label.config(text="🟡 Iniciando servidor...")
            self.root.update()
            
            # Determina o diretório do script
            if getattr(sys, 'frozen', False):
                script_dir = os.path.dirname(sys.executable)
            else:
                script_dir = os.path.dirname(os.path.abspath(__file__))
            
            # Caminho para o script Python
            script_path = os.path.join(script_dir, ".agente_csv_app.py")
            
            # Inicia o servidor em uma thread separada
            def run_server():
                try:
                    self.server_process = subprocess.Popen(
                        [sys.executable, script_path],
                        cwd=script_dir,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE
                    )
                    
                    # Aguarda um pouco para o servidor iniciar
                    time.sleep(3)
                    
                    # Atualiza a interface
                    self.root.after(0, self.server_started)
                    
                except Exception as e:
                    self.root.after(0, lambda: self.show_error(f"Erro ao iniciar servidor: {str(e)}"))
            
            thread = threading.Thread(target=run_server)
            thread.daemon = True
            thread.start()
            
        except Exception as e:
            self.show_error(f"Erro ao iniciar: {str(e)}")
            self.start_button.config(state="normal")
    
    def server_started(self):
        self.status_label.config(text="🟢 Servidor Rodando")
        self.open_button.config(state="normal")
        self.stop_button.config(state="normal")
        
        # Abre automaticamente no navegador
        self.open_browser()
    
    def open_browser(self):
        try:
            webbrowser.open("http://localhost:7860")
        except Exception as e:
            self.show_error(f"Erro ao abrir navegador: {str(e)}")
    
    def stop_server(self):
        try:
            if self.server_process:
                self.server_process.terminate()
                self.server_process = None
            
            self.status_label.config(text="🔴 Servidor Parado")
            self.start_button.config(state="normal")
            self.open_button.config(state="disabled")
            self.stop_button.config(state="disabled")
            
        except Exception as e:
            self.show_error(f"Erro ao parar servidor: {str(e)}")
    
    def close_app(self):
        try:
            # Para o servidor se estiver rodando
            if self.server_process:
                self.server_process.terminate()
            
            # Fecha a aplicação
            self.root.destroy()
            
        except Exception as e:
            self.root.destroy()
    
    def show_error(self, message):
        messagebox.showerror("Erro", message)
    
    def run(self):
        self.root.mainloop()

if __name__ == "__main__":
    app = AgenteCSVLauncher()
    app.run()


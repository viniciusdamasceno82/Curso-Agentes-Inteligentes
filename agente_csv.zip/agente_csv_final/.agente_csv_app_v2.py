import gradio as gr
import pandas as pd
import os
import sys
import plotly.express as px
import plotly.graph_objects as go

# Determina o caminho base do diretório atual
if getattr(sys, 'frozen', False):
    # Se estiver executando como executável
    base_dir = sys._MEIPASS
else:
    # Se estiver executando como script Python
    base_dir = os.path.dirname(os.path.abspath(__file__))

# Carrega os dados usando caminhos relativos ao arquivo atual
cabecalho = pd.read_csv(os.path.join(base_dir, "data", "202401_NFs_Cabecalho.csv"))
itens = pd.read_csv(os.path.join(base_dir, "data", "202401_NFs_Itens.csv"))

# Função para criar gráfico de linha
def criar_grafico_linha():
    # Simula dados de fornecedores ao longo do tempo
    fornecedores = ['Fornec A', 'Fornec B', 'Fornec C', 'Fornec D', 'Fornec E', 'Fornec F']
    pagamentos = [15, 20, 25, 15, 30, 35]
    faturas = [10, 15, 20, 25, 20, 30]
    
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=fornecedores, y=pagamentos, mode='lines+markers', name='Pagamentos', line=dict(color='#2ecc71')))
    fig.add_trace(go.Scatter(x=fornecedores, y=faturas, mode='lines+markers', name='Faturas', line=dict(color='#3498db')))
    
    fig.update_layout(
        title="Dedes de Fornecedor",
        xaxis_title="Fornecedores",
        yaxis_title="Percentual (%)",
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        font=dict(color='#2c3e50'),
        height=300
    )
    return fig

# Função para criar gráfico de pizza
def criar_grafico_pizza():
    # Dados baseados nos itens mais comuns
    top_itens = itens.groupby("DESCRIÇÃO DO PRODUTO/SERVIÇO")["QUANTIDADE"].sum().sort_values(ascending=False).head(5)
    
    fig = px.pie(
        values=top_itens.values,
        names=top_itens.index,
        title="Análise de Produtos",
        color_discrete_sequence=['#3498db', '#2ecc71', '#e74c3c', '#f39c12', '#9b59b6']
    )
    
    fig.update_layout(
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        font=dict(color='#2c3e50'),
        height=300
    )
    return fig

# Função para criar tabela de fornecedores
def criar_tabela_fornecedores():
    fornecedores_data = cabecalho.groupby("RAZÃO SOCIAL EMITENTE").agg({
        "VALOR NOTA FISCAL": ["count", "sum"]
    }).round(2)
    
    fornecedores_data.columns = ["Faturas", "Pagamentos"]
    fornecedores_data = fornecedores_data.head(5).reset_index()
    fornecedores_data.columns = ["Fornecedor", "Faturas", "Pagamentos"]
    
    return fornecedores_data

# Função de resposta
def responder_filtros(tipo, categoria):
    if tipo == "Fornecedor":
        if categoria == "Maior valor total":
            resultado = cabecalho.groupby("RAZÃO SOCIAL EMITENTE")["VALOR NOTA FISCAL"].sum().sort_values(ascending=False).head(1)
            return f"Fornecedor com maior valor total:\n{resultado.to_string()}"
        elif categoria == "Menor valor total":
            resultado = cabecalho.groupby("RAZÃO SOCIAL EMITENTE")["VALOR NOTA FISCAL"].sum().sort_values().head(1)
            return f"Fornecedor com menor valor total:\n{resultado.to_string()}"
        elif categoria == "Mais notas emitidas":
            resultado = cabecalho["RAZÃO SOCIAL EMITENTE"].value_counts().head(1)
            return f"Fornecedor que mais emitiu notas:\n{resultado.to_string()}"
        elif categoria == "Menos notas emitidas":
            resultado = cabecalho["RAZÃO SOCIAL EMITENTE"].value_counts().sort_values().head(1)
            return f"Fornecedor que menos emitiu notas:\n{resultado.to_string()}"

    elif tipo == "Item":
        if categoria == "Maior quantidade":
            resultado = itens.groupby("DESCRIÇÃO DO PRODUTO/SERVIÇO")["QUANTIDADE"].sum().sort_values(ascending=False).head(1)
            return f"Item com maior quantidade:\n{resultado.to_string()}"
        elif categoria == "Menor quantidade":
            resultado = itens.groupby("DESCRIÇÃO DO PRODUTO/SERVIÇO")["QUANTIDADE"].sum().sort_values().head(1)
            return f"Item com menor quantidade:\n{resultado.to_string()}"
        elif categoria == "Item mais caro":
            resultado = itens.sort_values(by="VALOR TOTAL", ascending=False).head(1)
            return f"Item de maior valor individual:\n{resultado[['DESCRIÇÃO DO PRODUTO/SERVIÇO','VALOR TOTAL']].to_string(index=False)}"
        elif categoria == "Item mais barato":
            resultado = itens[itens["VALOR TOTAL"] > 0].sort_values(by="VALOR TOTAL").head(1)
            return f"Item de menor valor individual:\n{resultado[['DESCRIÇÃO DO PRODUTO/SERVIÇO','VALOR TOTAL']].to_string(index=False)}"

    elif tipo == "Nota Fiscal":
        if categoria == "Total de notas":
            total = cabecalho["CHAVE DE ACESSO"].nunique()
            return f"Total de notas fiscais: {total}"
        elif categoria == "Média dos valores":
            media = cabecalho["VALOR NOTA FISCAL"].mean()
            return f"Média de valores das notas: R$ {media:,.2f}"
        elif categoria == "Nota de menor valor":
            menor = cabecalho[["CHAVE DE ACESSO", "VALOR NOTA FISCAL"]].sort_values(by="VALOR NOTA FISCAL").head(1)
            return f"Nota de menor valor:\n{menor.to_string(index=False)}"
        elif categoria == "Valor total das notas":
            total = cabecalho["VALOR NOTA FISCAL"].sum()
            return f"Valor total de todas as notas: R$ {total:,.2f}"

    elif tipo == "Data":
        cabecalho["DATA EMISSÃO"] = pd.to_datetime(cabecalho["DATA EMISSÃO"])
        if categoria == "Data com mais notas":
            dias = cabecalho["DATA EMISSÃO"].dt.date.value_counts().sort_values(ascending=False).head(1)
            return f"Data com mais notas emitidas:\n{dias.to_string()}"
        elif categoria == "Data com menos notas":
            dias = cabecalho["DATA EMISSÃO"].dt.date.value_counts().sort_values().head(1)
            return f"Data com menos notas emitidas:\n{dias.to_string()}"

    return "Selecione uma opção válida."

# Mapeia categorias por tipo
opcoes_categorias = {
    "Fornecedor": ["Maior valor total", "Menor valor total", "Mais notas emitidas", "Menos notas emitidas"],
    "Item": ["Maior quantidade", "Menor quantidade", "Item mais caro", "Item mais barato"],
    "Nota Fiscal": ["Total de notas", "Média dos valores", "Nota de menor valor", "Valor total das notas"],
    "Data": ["Data com mais notas", "Data com menos notas"]
}

# Calcula métricas principais
total_faturas = cabecalho["VALOR NOTA FISCAL"].sum()
total_pagamentos = total_faturas * 0.6  # Simula 60% pago
a_pagar = total_faturas - total_pagamentos

# Custom CSS inspirado na imagem
custom_css = """
.gradio-container {
    max-width: 1400px !important;
    margin: 0 auto !important;
    background-color: #f8f9fa !important;
}

.sidebar {
    background: linear-gradient(180deg, #2c3e50 0%, #34495e 100%) !important;
    color: white !important;
    padding: 20px !important;
    border-radius: 15px !important;
    min-height: 600px !important;
}

.metric-card {
    background: white !important;
    border-radius: 15px !important;
    padding: 25px !important;
    box-shadow: 0 4px 20px rgba(0,0,0,0.08) !important;
    margin-bottom: 20px !important;
    border: 1px solid #e9ecef !important;
}

.chart-card {
    background: white !important;
    border-radius: 15px !important;
    padding: 20px !important;
    box-shadow: 0 4px 20px rgba(0,0,0,0.08) !important;
    margin-bottom: 20px !important;
    border: 1px solid #e9ecef !important;
}

.main-title {
    color: #2c3e50 !important;
    font-size: 28px !important;
    font-weight: 700 !important;
    margin-bottom: 10px !important;
}

.metric-title {
    font-size: 14px !important;
    color: #6c757d !important;
    margin-bottom: 10px !important;
    font-weight: 500 !important;
}

.metric-value {
    font-size: 32px !important;
    font-weight: 700 !important;
    color: #2c3e50 !important;
    margin: 0 !important;
}
"""

# Interface com Blocks
with gr.Blocks(title="Análise de Faturas", css=custom_css) as demo:
    with gr.Row():
        # Sidebar
        with gr.Column(scale=1, elem_classes="sidebar"):
            gr.HTML("""
            <div style="text-align: center; margin-bottom: 30px;">
                <div style="background: #3498db; width: 50px; height: 50px; border-radius: 10px; display: flex; align-items: center; justify-content: center; margin: 0 auto 15px;">
                    <span style="color: white; font-size: 24px; font-weight: bold;">PJ</span>
                </div>
            </div>
            
            <div style="margin-bottom: 20px;">
                <div style="display: flex; align-items: center; margin-bottom: 15px; padding: 10px; border-radius: 8px; background: rgba(255,255,255,0.1);">
                    <span style="margin-right: 10px;">💬</span>
                    <span>Chat</span>
                </div>
                <div style="display: flex; align-items: center; margin-bottom: 15px; padding: 10px; border-radius: 8px;">
                    <span style="margin-right: 10px;">⏰</span>
                    <span>Histórico</span>
                </div>
                <div style="display: flex; align-items: center; margin-bottom: 15px; padding: 10px; border-radius: 8px;">
                    <span style="margin-right: 10px;">📁</span>
                    <span>Arquivos</span>
                </div>
                <div style="display: flex; align-items: center; margin-bottom: 15px; padding: 10px; border-radius: 8px;">
                    <span style="margin-right: 10px;">🔌</span>
                    <span>Plugins</span>
                </div>
                <div style="display: flex; align-items: center; margin-bottom: 15px; padding: 10px; border-radius: 8px;">
                    <span style="margin-right: 10px;">👤</span>
                    <span>Perfil</span>
                </div>
                <div style="display: flex; align-items: center; margin-bottom: 15px; padding: 10px; border-radius: 8px;">
                    <span style="margin-right: 10px;">🖼️</span>
                    <span>Galeria</span>
                </div>
                <div style="display: flex; align-items: center; margin-bottom: 15px; padding: 10px; border-radius: 8px;">
                    <span style="margin-right: 10px;">⚙️</span>
                    <span>Config</span>
                </div>
                <div style="display: flex; align-items: center; margin-bottom: 15px; padding: 10px; border-radius: 8px;">
                    <span style="margin-right: 10px;">📁</span>
                    <span>Pasta</span>
                </div>
            </div>
            """)

        # Main content
        with gr.Column(scale=4):
            # Header
            gr.HTML("""
            <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 30px;">
                <div style="display: flex; align-items: center;">
                    <div style="background: #3498db; width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-right: 15px;">
                        <span style="color: white; font-size: 16px;">📊</span>
                    </div>
                    <h1 class="main-title">Análise de Faturas</h1>
                </div>
                <div style="background: white; border-radius: 10px; padding: 10px 15px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); border: 1px solid #e9ecef; display: flex; align-items: center;">
                    <input type="text" placeholder="Fornecedos" style="border: none; outline: none; background: transparent; margin-right: 10px;">
                    <span style="color: #6c757d;">🔍</span>
                </div>
            </div>
            """)

            # Métricas principais
            with gr.Row():
                with gr.Column(scale=1, elem_classes="metric-card"):
                    gr.HTML(f"""
                    <div class="metric-title">Total de Faturas</div>
                    <div class="metric-value">R$ {total_faturas:,.0f}</div>
                    """)
                with gr.Column(scale=1, elem_classes="metric-card"):
                    gr.HTML(f"""
                    <div class="metric-title">Total de Pagamentos</div>
                    <div class="metric-value">R$ {total_pagamentos:,.0f}</div>
                    """)
                with gr.Column(scale=1, elem_classes="metric-card"):
                    gr.HTML(f"""
                    <div class="metric-title">A Pagar</div>
                    <div class="metric-value">R$ {a_pagar:,.0f}</div>
                    <div style="margin-top: 10px;">
                        <svg width="100" height="30" viewBox="0 0 100 30">
                            <path d="M0,15 Q25,5 50,15 T100,15" stroke="#3498db" stroke-width="2" fill="none"/>
                        </svg>
                    </div>
                    """)

            # Gráficos
            with gr.Row():
                with gr.Column(scale=1, elem_classes="chart-card"):
                    gr.HTML("<h3 style='margin-bottom: 15px; color: #2c3e50;'>Dedes de Fornecedor</h3>")
                    grafico_linha = gr.Plot(value=criar_grafico_linha())
                with gr.Column(scale=1, elem_classes="chart-card"):
                    gr.HTML("<h3 style='margin-bottom: 15px; color: #2c3e50;'>Análise de Produtos</h3>")
                    grafico_pizza = gr.Plot(value=criar_grafico_pizza())

            # Tabela e análise
            with gr.Row():
                with gr.Column(scale=1, elem_classes="chart-card"):
                    gr.HTML("<h3 style='margin-bottom: 15px; color: #2c3e50;'>Análise de Fornecedores</h3>")
                    tabela_fornecedores = gr.Dataframe(
                        value=criar_tabela_fornecedores(),
                        headers=["Fornecedor", "Faturas", "Pagamentos"],
                        interactive=False
                    )
                with gr.Column(scale=1, elem_classes="chart-card"):
                    gr.HTML("<h3 style='margin-bottom: 15px; color: #2c3e50;'>Análise de Fornecedores</h3>")
                    top_fornecedor = cabecalho.groupby("RAZÃO SOCIAL EMITENTE")["VALOR NOTA FISCAL"].sum().sort_values(ascending=False).head(1)
                    gr.HTML(f"""
                    <div style="font-size: 18px; color: #2c3e50;">
                        <strong>Fornec A</strong><br>
                        <span style="font-size: 24px; font-weight: bold;">283.100</span>
                    </div>
                    """)

            # Controles de análise
            with gr.Row():
                with gr.Column(scale=1, elem_classes="chart-card"):
                    gr.HTML("<h3 style='margin-bottom: 15px; color: #2c3e50;'>Análise Personalizada</h3>")
                    with gr.Row():
                        tipo = gr.Dropdown(
                            choices=list(opcoes_categorias.keys()),
                            label="Tipo de informação",
                            container=False
                        )
                        categoria = gr.Dropdown(
                            choices=[],
                            label="Categoria",
                            container=False
                        )
                    botao = gr.Button("Gerar Análise", variant="primary", size="lg")
                    
                with gr.Column(scale=1, elem_classes="chart-card"):
                    gr.HTML("<h3 style='margin-bottom: 15px; color: #2c3e50;'>Resultado da Análise</h3>")
                    saida = gr.Textbox(
                        label="",
                        lines=8,
                        container=False,
                        show_label=False
                    )

    def atualizar_categorias(tipo_escolhido):
        return gr.update(choices=opcoes_categorias.get(tipo_escolhido, []))

    tipo.change(fn=atualizar_categorias, inputs=tipo, outputs=categoria)
    botao.click(fn=responder_filtros, inputs=[tipo, categoria], outputs=saida)

if __name__ == "__main__":
    demo.launch(server_name="0.0.0.0", server_port=7860, share=False)


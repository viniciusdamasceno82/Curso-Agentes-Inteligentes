#!/bin/bash

# Script de execução do Agente CSV com interface gráfica

echo "Iniciando Agente CSV..."

# Verifica se o Python está instalado
if ! command -v python3 &> /dev/null; then
    echo "Python3 não encontrado. Por favor, instale o Python 3.7 ou superior."
    exit 1
fi

# Instala as dependências se necessário
pip3 install gradio pandas plotly tkinter > /dev/null 2>&1

# Executa a interface gráfica
python3 iniciar.py

